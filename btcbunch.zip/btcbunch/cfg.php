<?

$cookie = "ga_MTE2VX5MJ9=GS1.1.1639031331.1.1.1639031505.0;csrf_cookie_name=9617a70ac1c33de6a8d036c12eaa571b;cto_bidid=xpVH1V9KTVclMkJIR3AlMkZyRnlzQ1klMkZnZ1ZhVmMxZlAlMkZPOWtjbk9sZVIwQk10T1RYa3JQazczbGxKd2gweVZTQkp4OTBuTUQ4VkxDeXlFV2JUNzFpYTJaJTJCSkRKTFE3bkh1bGlUVGRueXRFVXhEUEIzMnMlM0Q;cto_bundle=3bIaRl9qd3pmcDR3UEJTa0JDellMcUpRT1BZcm9EQTRQbEoyNDg2SzN3MjloMmoyMWZnUWh1alRUUUVCQ05lN21kdE0xV0FwaHdBWWlCU05VRmkxRUtsMXVKNGsyd1BodGszY2tBT0kzck0wRmJPMTRJTnF0WGVnMlhacWFBN2E3byUyQjVMZlVIYjY3MGdESnhKRktmcWlOVHBwQSUzRCUzRA;gads=ID=1ccdfbc803768068-22f0365160cf007f:T=1639031345:RT=1639031345:S=ALNI_MZlJ4JPwy-Rpu0gLsWhr5T1Q7lVDQ;bitmedia_fid=eyJmaWQiOiIyZDk2YjRmNzlhMjc0ZTc2NGJmMzdkMjZlZDllZTIxNiIsImZpZG5vdWEiOiJiMTgzMDc4NDUyZmFiYTIwYjcxYTY2OTEyYzBlM2JiZCJ9;clever-counter-54448=0-1;clever-last-tracker-54448=1;viCookieActive=true;_pbjs_userid_consent_data=3524755945110770;compass_uid=aa2038dd-f246-XMR-XMR%22timesVisited%22%3A1%7D;__nrbic=%7B%22previousVisit%22%3A1639031332%2C%22currentVisitStarted%22%3A1639031332%2C%22sessionId%22%3A%22937203f5-ce06-446c-9cd3-6efed81c4596%22%2C%22sessionVars%22%3A%5B%5D%2C%22visitedInThisSession%22%3Atrue%2C%22pagesViewed%22%3A1%2C%22landingPage%22%3A%22https%3A//btcbunch.com/%22%2C%22referrer%22%3A%22%22%7D;_ga=GA1.1.1883512286.1639031332;ci_session=6ste1mlgu6qglsdlcq1olmmcii4328mn";
$user_agent = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/71.0.3578.141 Safari/534.24 XiaoMi/MiuiBrowser/12.5.2-go";

/* WITHDRAW */
/* Wallet or Email */
$wallet="harunharmain28@gmail.com";

/*
1-BTC Via FaucetPay -> 100 Tokens
2-LTC Via FaucetPay -> 100 Tokens
3-DOGE Via FaucetPay -> 100 Tokens
4-DASH Via FaucetPay -> 100 Tokens
5-USDT Via FaucetPay -> 100 Tokens
6-TRX Via FaucetPay -> 100 Tokens
7-BNB Via FaucetPay -> 100 Tokens
8-ZEC Via FaucetPay -> 100 Tokens
9-USD Via Payeer -> 500000 Tokens
10-PAYPAL -> 500000 Tokens
11-UPI Transfer(only for Indians) -> 500000 Tokens
12-Google Play Redeem Code -> 500000 Tokens
INPUT NUMBER ONLY
*/

$coin_number="2";
/*
Auto Withdraw every .... Tokens
INPUT NUMBER ONLY
*/

$ammount_withdraw="5000";

/*Detik*/
$timer="490";