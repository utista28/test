========================
$ pkg update
$ pkg upgrade
$ pkg install php
$ pkg install git
$ termux-setup-storage
========================
RUN SC : 
$ git clone https://github.com/iewilmaestro/btcbunch
$ cd btcbunch
-> edit cfg.php sesuai kebutuhan
$ php bot.php
